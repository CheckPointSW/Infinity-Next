#!/usr/bin/env sh

install_terraform_provider() {
  mkdir -p ~/.terraform.d/plugins/checkpoint.com/main/infinity-next/1.0.2/linux_amd64 && \
  chmod +x "$1"/terraform-provider-infinity-next_v1.0.2 && \
  cp "$1"/terraform-provider-infinity-next_v1.0.2 ~/.terraform.d/plugins/checkpoint.com/main/infinity-next/1.0.2/linux_amd64 && \
  chmod +x "$1"/inext
  cp "$1"/inext /usr/local/bin && \
  chmod +x /usr/local/bin/inext
}

install_terraform() {
  curl -fsSL https://apt.releases.hashicorp.com/gpg | sudo apt-key add && \
  sudo apt-add-repository "deb [arch=amd64] https://apt.releases.hashicorp.com $(lsb_release -cs) main" && \
  sudo apt update && \
  sudo apt install terraform
}

get_k8s_objects_as_json() {
  kubectl get appsecpractice -A -o json > practice.json && \
  kubectl get appseclogtrigger -A -o json > trigger.json && \
  kubectl get ingress -A -o json > assets.json && \
  kubectl get appsecpolicies -A -o json > policy.json && \
  kubectl get webuserresponse -A -o json > user_response.json
}

rm -rf ./*.tf

get_k8s_objects_as_json
if [ "$?" -ne "0" ]; then
    exit 1
fi

DIR=$(pwd)
chmod +x "$DIR"/json-to-terraform
"$DIR"/json-to-terraform
if [ "$?" -ne "0" ]; then
  exit 1
fi

echo "Deploying your environment.."
install_terraform && install_terraform_provider "$DIR" && terraform init && terraform apply -auto-approve
if [ "$?" -ne "0" ]; then
  exit 2
fi

inext publish --region "private" --tenant-id "$INEXT_TENANT_ID" --user-id "$INEXT_USER_ID" --client-id "123" --access-key "123" --host "$INEXT_HOST"
if [ "$?" -ne "0" ]; then
  exit 2
fi

helm upgrade cp-appsec ./ -n appsec --set appsec.mode=full --set appsec.persistence.enabled=false --set controller.ingressClassResource.name="appsec-nginx" --set controller.ingressClassResource.controllerValue="k8s.io/appsec-nginx" --set appsec.agentToken="$INEXT_TOKEN" --recreate-pods
kubectl delete pods cp-appsec-cp-k8s-appsec-nginx-ingress-controller-0 -n appsec --force
#sudo apt purge terraform -y
#rm -rf ./*.json ~/.terraform.d /usr/local/bin/inext

#./open-appsec.sh 7a194fba-dc87-4302-8807-42cc765f18c3 123456

#rm -rf ./*.json ~/.terraform.d /usr/local/bin/inext ./*.tf ./terraform.tfstate* ./.terraform*

# profile-id 4cc0da6d-e1e5-95a1-f82e-eb214afb176d
# tenant-id org_uFOSDjWVijq3IQzt
# token cp-9cb19356-ef35-4e7b-80d1-a09ce8ffb8eeafad5c1c-df69-4d7c-bb43-add161813f8c

#wget https://github.com/CheckPointSW/Infinity-Next/raw/tf/deployments/json-to-terraform.zip -O tools.zip