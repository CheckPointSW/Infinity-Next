#!/usr/bin/env sh

DIR=$(pwd)
export INEXT_HOST="https://dev-latest-elpis.dev.i2.checkpoint.com"
export INEXT_USER_ID="elpis123"

range=$(($#-1))
for i in $(seq 1 $range); do
  eval "flag_arg=\$$i"
  flag=$(echo $flag_arg)
  if [ "$flag" = "--tenant-id" ]; then
    j=$(($i+1))
    eval "val_arg=\$$j"
    val=$(echo $val_arg)
    export INEXT_TENANT_ID="$val"
  fi
  if [ "$flag" = "--profile-id" ]; then
    j=$(($i+1))
    eval "val_arg=\$$j"
    val=$(echo $val_arg)
    export INEXT_PROFILE_ID="$val"
  fi
  if [ "$flag" = "--token" ]; then
    j=$(($i+1))
    eval "val_arg=\$$j"
    val=$(echo $val_arg)
    export INEXT_TOKEN="$val"
  fi
done

chmod +x ./yaml-to-terraform.sh
"$DIR"/yaml-to-terraform.sh > "$DIR"/log.txt
if [ "$?" -eq "1" ]; then
  echo "Fail to update configuration on management"
  exit 1
elif [ "$?" -eq "2" ]; then
  echo "Fail to connect to cloud management"
  exit 1
else
  echo "Successfully connected to cloud management and deployed your environment"
fi
